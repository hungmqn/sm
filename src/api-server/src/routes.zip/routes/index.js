const Base = require('./base');
const api = require('./api');

class IndexRoute extends Base {
  constructor() {
    super();
    this.router.use(`/api/${config.apiVersion}`, api);
  }
}
module.exports = new IndexRoute().router;
