const user = require('./user');
const BaseRouter = require('../base');

class Api extends BaseRouter {
  constructor() {
    super();
    this.router.use('/user', user);
  }
}

module.exports = new Api().router;